# Vin-o-bot
This is a web application for wine recommendation, made as a Final assignment of the course Knowledge and Data
